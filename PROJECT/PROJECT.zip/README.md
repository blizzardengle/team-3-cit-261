# CIT 261 Team 3
Team 3 group repository for Brigham Young University - Idaho's Spring 2016 CIT 261 Mobile Application Development class.

This will be the repository we use for our group project.
